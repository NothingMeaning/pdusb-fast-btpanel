# -*- coding: utf-8 -*-

from qiniu.region import Region


class Zone(Region):
    pass
