# -*- coding: utf-8 -*-

__title__ = 'upyun'
__author__ = 'Leili Xu'
__license__ = 'MIT License: http://www.opensource.org/licenses/mit-license.php'
__copyright__ = 'Copyright 2015 UPYUN'
